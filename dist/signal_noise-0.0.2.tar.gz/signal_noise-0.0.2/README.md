# signal_noise
It is a library with methods which can measurement signal/noise. 

![PyPI](https://img.shields.io/pypi/v/signal_noise?color=orange) ![Python 3.9, 3.10, 3.11](https://img.shields.io/pypi/pyversions/signal_noise?color=blueviolet) ![GitHub Pull Requests](https://img.shields.io/github/issues-pr/89605502155/signal_noise?color=blueviolet) ![License](https://img.shields.io/pypi/l/signal_noise?color=blueviolet) ![Forks](https://img.shields.io/github/forks/89605502155/signal_noise?style=social)

**signal_noise** - this module is a Python library for the calculation signal-noise metric in data.

## Installation

Install the current version with [PyPI](https://pypi.org/project/):

```bash
pip install signal_noise
```

Or from Github:
```bash
pip install https://github.com/89605502155/signal_noise/main.zip
```
